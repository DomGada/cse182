SELECT DISTINCT t1.teamID AS team1, t1.teamCity as team1City, t2.teamID AS team2,  t2.teamCity AS team2City
FROM Games g, Teams t1, Teams t2
WHERE g.homeTeam = t1.teamID
        AND g.visitorTeam = t2.teamID
        AND g.homePoints > g.visitorPoints
        AND 0 = (
SELECT COUNT (*) 
FROM Games g2
WHERE g2.homeTeam = g.visitorTeam AND g2.visitorTeam = g.homeTeam
        AND g2.homePoints > g2.visitorPoints
)
