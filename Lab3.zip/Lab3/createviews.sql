CREATE VIEW WinsDisagree AS
    SELECT t.teamID, t.teamName, t.totalWins, @computedWins
    FROM Teams t
    WHERE
    totalWins != (
        SELECT @computedWins
        FROM Games g
        WHERE @computedWins :=
        count(SELECT )
        
    )   